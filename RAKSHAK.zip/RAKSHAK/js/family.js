export function validatePhoneNumber(phoneNumber) {
    if (typeof phoneNumber !== "string") {
        throw new Error("Invalid phone number");
    }

    const phone = phoneNumber
        .trim()
        .replace(/[\s()+-]/g, "");

    if (!/^[1-9]\d{7,14}$/.test(phone)) {
        throw new Error("Invalid phone number. Include country code.");
    }

    return phone;
}


// Prepare RAKSHAK family alert
export function shareFamilyAlert(result, phoneNumber) {

    const phone = validatePhoneNumber(phoneNumber);

    if (!result || typeof result !== "object") {
        throw new Error("Invalid risk result");
    }

    const riskLevel = String(result.riskLevel || "UNKNOWN");

    const reasons = Array.isArray(result.reasons)
        ? result.reasons.slice(0, 3).map(String)
        : [];

    const message = `
🚨 RAKSHAK SAFETY ALERT

Risk Level: ${riskLevel}

Reasons:
${reasons.map((r, i) => `${i + 1}. ${r}`).join("\n")}

Please check and contact the person if needed.

Sent using RAKSHAK.
`;

    return {
        message,
        whatsappURL:
            `https://wa.me/${phone}?text=${encodeURIComponent(message)}`,
        callURL: `tel:+${phone}`
    };
}


// Connect family buttons
export function setupFamilyButtons(result, phoneNumber) {

    const shareButton =
        document.getElementById("shareFamilyAlert");

    const callButton =
        document.getElementById("callFamily");

    if (!shareButton || !callButton) {
        throw new Error("Family buttons not found");
    }

    const alert = shareFamilyAlert(result, phoneNumber);
    shareButton.disabled = false;
    callButton.disabled = false;

    shareButton.onclick = function () {
        window.open(
            alert.whatsappURL,
            "_blank",
            "noopener,noreferrer"
        );
    };

   callButton.onclick = function () {

    const confirmed = confirm(
        "Do you want to open the family calling application?"
    );

    if (confirmed) {
        window.location.href = alert.callURL;
    }
};

    return true;
}