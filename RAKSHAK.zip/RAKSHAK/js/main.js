import { setupFamilyButtons } from "./family.js?v=20261122";

const familyForm = document.getElementById("familyForm");
const familyPhone = document.getElementById("familyPhone");
const familyStatus = document.getElementById("familyStatus");

if (familyForm && familyPhone && familyStatus) {
    familyForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const result = {
            riskLevel: "HIGH",
            reasons: [
                "Suspicious payment request detected",
                "Unknown sender detected",
                "Potential phishing link identified"
            ]
        };

        try {
            setupFamilyButtons(result, familyPhone.value);
            familyStatus.textContent =
                "RAKSHAK: Family contact connected successfully!";
        } catch (error) {
            familyStatus.textContent =
                error instanceof Error ? error.message : "Unable to connect family contact.";
        }
    });
}