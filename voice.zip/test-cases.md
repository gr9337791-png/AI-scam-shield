
// TRUST CIRCLE - Voice Assistant
// Member 4

// Check whether the browser supports speech
function isVoiceSupported() {
    return (
        "speechSynthesis" in window &&
        "SpeechSynthesisUtterance" in window
    );
}

// Find a suitable voice for the selected language
function findVoice(language) {
    const voices = window.speechSynthesis.getVoices();

    const languagePrefix = language.toLowerCase().split("-")[0];

    return voices.find(voice =>
        voice.lang.toLowerCase().startsWith(languagePrefix)
    ) || null;
}

// Main function used by the complete application
function speakWarning(text, language = "hi-IN") {

    if (!isVoiceSupported()) {
        alert("Voice is not supported in this browser.");
        return;
    }

    if (!text || !text.trim()) {
        console.warn("No warning text provided.");
        return;
    }

    // Stop previous speech
    window.speechSynthesis.cancel();

    const message = new SpeechSynthesisUtterance(text);

    message.lang = language;
    message.rate = 0.85; // Slower speech for elderly users
    message.pitch = 1;
    message.volume = 1;

    // Select the best available voice
    const selectedVoice = findVoice(language);

    if (selectedVoice) {
        message.voice = selectedVoice;
    }

    message.onstart = () => {
        console.log("Voice warning started.");
    };

    message.onend = () => {
        console.log("Voice warning completed.");
    };

    message.onerror = (event) => {
        console.error("Voice error:", event.error);
    };

    window.speechSynthesis.speak(message);
}

// Stop voice when requested
function stopWarning() {
    if (isVoiceSupported()) {
        window.speechSynthesis.cancel();
    }
}

// Make functions available to the other application files
window.speakWarning = speakWarning;
window.stopWarning = stopWarning;
window.isVoiceSupported = isVoiceSupported;

const safetyMessages = {
    hi: {
        scam: "सावधान! यह संदेश धोखाधड़ी हो सकता है। अपना OTP किसी के साथ साझा न करें।",
        payment: "सावधान! पैसे भेजने से पहले अपने परिवार के सदस्य से बात करें।",
        safe: "इस संदेश में कोई स्पष्ट खतरे का संकेत नहीं मिला। फिर भी सावधानी रखें।"
    },

    en: {
        scam: "Warning! This message may be a scam. Never share your OTP.",
        payment: "Warning! Speak to your family before sending money.",
        safe: "No obvious warning signs were detected. Please remain cautious."
    }
};

window.safetyMessages = safetyMessages;
