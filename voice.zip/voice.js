
/* TRUST CIRCLE - Voice Assistant
   Member 4
*/

function isVoiceSupported() {
    return (
        "speechSynthesis" in window &&
        "SpeechSynthesisUtterance" in window
    );
}

// Get all voices installed on the device
function getAvailableVoices() {
    if (!isVoiceSupported()) return [];
    return window.speechSynthesis.getVoices();
}

// Find the correct language voice
function findVoice(language) {
    const voices = getAvailableVoices();

    const prefix = language.toLowerCase().split("-")[0];

    return voices.find(voice =>
        voice.lang.toLowerCase().startsWith(prefix)
    ) || null;
}

// Main speaking function
function speakWarning(text, language = "hi-IN") {

    if (!isVoiceSupported()) {
        return {
            success: false,
            message: "Speech is not supported in this browser."
        };
    }

    if (!text || !text.trim()) {
        return {
            success: false,
            message: "No warning message provided."
        };
    }

    const voice = findVoice(language);

    // Do not use an English voice to pretend to speak Hindi
    if (language.startsWith("hi") && !voice) {
        return {
            success: false,
            message: "Hindi voice is not installed on this device."
        };
    }

    const synth = window.speechSynthesis;

    synth.cancel();

    const speech = new SpeechSynthesisUtterance(text);

    speech.lang = voice ? voice.lang : language;
    speech.rate = 0.85;
    speech.pitch = 1;
    speech.volume = 1;

    if (voice) {
        speech.voice = voice;
    }

    speech.onstart = () => {
        console.log("Voice started:", speech.lang);
    };

    speech.onend = () => {
        console.log("Voice completed.");
    };

    speech.onerror = (event) => {
        console.error("Speech error:", event.error);
    };

    synth.speak(speech);

    return {
        success: true,
        message: "Speech started.",
        voiceName: voice ? voice.name : "Device default"
    };
}

// Stop speaking
function stopWarning() {
    if (isVoiceSupported()) {
        window.speechSynthesis.cancel();
    }
}

// Make functions accessible to other JavaScript files
window.isVoiceSupported = isVoiceSupported;
window.getAvailableVoices = getAvailableVoices;
window.findVoice = findVoice;
window.speakWarning = speakWarning;
window.stopWarning = stopWarning;
